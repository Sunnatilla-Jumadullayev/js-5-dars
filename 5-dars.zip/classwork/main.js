const score = document.querySelector("h1")
const elBtn = document.querySelector("button")
const elInput = document.querySelector("input")
const humanspeed = 3.6
const bycspeed = 20.1
const carspeed = 70
const pilotspeed = 800
var htime
var hdaqiqa

var btime
var btime

var ctime
var cdaqiqa

var ptime
var pdaqiqa




elInput.value

elBtn.addEventListener("click", function () {
    htime = (elInput.value / humanspeed)
    hdaqiqa = htime - Math.floor(htime)
    hdaqiqa = Math.floor(hdaqiqa * 60)
    htime = Math.floor(htime)

    const hresult = document.querySelector("#piyoda")
    hresult.innerText = htime + " soat " + hdaqiqa + " daqiqa"

    console.log(hresult)

    btime = (elInput.value / bycspeed)
    bdaqiqa = btime - Math.floor(btime)
    bdaqiqa = Math.floor(bdaqiqa * 60)
    btime = Math.floor(btime)

    const bresult = document.querySelector("#bycicle")
    bresult.innerText = btime + " soat " + bdaqiqa + " daqiqa"

    console.log(bresult)

    ptime = (elInput.value / pilotspeed)
    pdaqiqa = ptime - Math.floor(ptime)
    pdaqiqa = Math.floor(pdaqiqa * 60)
    ptime = Math.floor(ptime)

    const presult = document.querySelector("#pilot")
    presult.innerText = ptime + " soat " + pdaqiqa + " daqiqa"

    console.log(presult)







})
elBtn.addEventListener("click", function () {
    ctime = (elInput.value / carspeed)
    cdaqiqa = ctime - Math.floor(ctime)
    cdaqiqa = Math.floor(cdaqiqa * 60)
    ctime = Math.floor(ctime)

    const cresult = document.querySelector("#car")
    cresult.innerText = ctime + " soat " + cdaqiqa + " daqiqa"

    console.log(cresult)

})

